JOHN DEERE SOUTH AFRICA WEBSITE - PART 2

Updated version includes:
- Automatic About Us image slideshow
- About Us hover effect for customer reading/content cards
- Cards lift slightly, highlight with John Deere green/yellow, and show a small 'Hover to explore' prompt
- Responsive/mobile-friendly behavior
- Reduced-motion accessibility support

Keep index.html, style.css and the images folder together after extracting the ZIP.
